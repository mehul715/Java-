

import java.awt.BorderLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;


public class LAB_12_gui_sorting extends JPanel
implements ActionListener {
	static private final String newline = "\n";
	//private static final String[] stockArr = null;
	JButton mergeButton, selectionButton, quickButton, insertionButton;
	JTextArea log;
	JFileChooser fileChooser;
	InsertionSort ins = new InsertionSort();
	MergeSort merge = new MergeSort();
	QuickSort qs = new QuickSort();
	SelectionSortS ss = new SelectionSortS();
	ArrayList<String>arr = new ArrayList<String>();
	String[] stockArr = new String[arr.size()];
	String[] stockArr2=new String[arr.size()];
	String[] stockArr3=new String[arr.size()];

	public LAB_12_gui_sorting() throws IOException {
		super(new BorderLayout());


		//Create the log first, because the action listeners
		//need to refer to it.
		log = new JTextArea(5,20);
		log.setMargin(new Insets(85,50,90,126));
		log.setEditable(false);
		JScrollPane logScrollPane = new JScrollPane(log);

		fileChooser = new JFileChooser();
		quickButton = new JButton("Quick Sort");
		quickButton.addActionListener(this);

		fileChooser = new JFileChooser();
		insertionButton = new JButton("Insertion Sort");
		insertionButton.addActionListener(this);

		fileChooser = new JFileChooser();
		mergeButton = new JButton("Merge Sort");
		mergeButton.addActionListener(this);

		fileChooser = new JFileChooser();
		selectionButton = new JButton("Selection Sort");
		selectionButton.addActionListener(this);

		//For layout purposes, put the buttons in a separate panel
		JPanel buttonPanel = new JPanel(); //use FlowLayout
		buttonPanel.add(mergeButton);
		buttonPanel.add(selectionButton);
		buttonPanel.add(quickButton);
		buttonPanel.add(insertionButton);

		//Add the buttons and the log to this panel.
		add(buttonPanel, BorderLayout.PAGE_START);
		add(logScrollPane, BorderLayout.CENTER);
		BufferedReader br = new BufferedReader(new FileReader("inventory.txt"));
		String line = null;
		while(((line=br.readLine())!=null))
		{
			arr.add(line);
			ss.add(line);
		}
		stockArr = arr.toArray(stockArr);
		stockArr2=arr.toArray(stockArr);
		stockArr3=arr.toArray(stockArr);


	}
	public String insertionSort(){
		long startTime = System.nanoTime();
		ins.Sort(stockArr, stockArr.length-1);
		long endTime = System.nanoTime();
		long td = endTime-startTime;
		return ("Insertion sort time is " + td);
	}

	public String mergeSort(){
		String[] temp = null;
		long startTime3 = System.nanoTime();
		merge.Sort(stockArr3);
		long endTime3 = System.nanoTime();
		long td3 = endTime3-startTime3;
		return("Merge sort time is " + td3);

	}
	public String selectionSort(){
		long startTime1 = System.nanoTime();
		ss.sort();
		long endTime1 = System.nanoTime();
		long td1 = endTime1-startTime1;
		return("Selection sort time is " + td1);

	}
	public String quickSort(){
		long startTime2 = System.nanoTime();
		qs.qsort(stockArr2, 0, stockArr2.length-1);
		long endTime2 = System.nanoTime();
		long td2 = endTime2-startTime2;
		return("Quick sort time is " + td2);

	}

	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==insertionButton)
			log.setText("Total records are: " + (stockArr.length-1) + "\n\n" +insertionSort());
		if(e.getSource()==mergeButton)
			log.setText("Total records are: " + (stockArr.length-1) + "\n\n" +mergeSort());
		if(e.getSource()==selectionButton)
			log.setText("Total records are: " + (stockArr.length-1) + "\n\n" +selectionSort());
		if(e.getSource()==quickButton)
			log.setText("Total records are: " + (stockArr.length-1) + "\n\n" +quickSort());

	}


	private static void createAndShowGUI() throws IOException {
		//Create and set up the window.
		JFrame frame = new JFrame("Sorting Time");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		//Add content to the window.
		frame.add(new LAB_12_gui_sorting());

		//Display the window.
		frame.pack();
		frame.setVisible(true);


	}

	public static void main(String[] args) {
		//Schedule a job for the event dispatch thread:
		//creating and showing this application's GUI.
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				//Turn off metal's use of bold fonts
				UIManager.put("swing.boldMetal", Boolean.FALSE);
				try {
					createAndShowGUI();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
	}
}