import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;


public class lab_12_Sorting {

	public static void main(String[] args) throws IOException {
		ArrayList<String>arr = new ArrayList<>();
		BufferedReader br = new BufferedReader(new FileReader("inventory.txt"));
		SelectionSortS ss = new SelectionSortS();
		String line = null;

		while(((line=br.readLine())!=null))
		{
			arr.add(line);
			ss.add(line);
		}

		String[] stockArr = new String[arr.size()];
		String[] stockArr2=new String[arr.size()];
		String[] stockArr3=new String[arr.size()];
		stockArr = arr.toArray(stockArr);
		stockArr2=arr.toArray(stockArr);
		stockArr3=arr.toArray(stockArr);

		InsertionSort ins = new InsertionSort();
		MergeSort merge = new MergeSort();
		QuickSort qs = new QuickSort();

		//Insertion sort
		long startTime = System.nanoTime();
		ins.Sort(stockArr, stockArr.length-1);
		long endTime = System.nanoTime();
		long td = System.nanoTime()-startTime;
		System.out.println("Total records are "+ (stockArr.length-1));
		System.out.println("Insertion sort time is " + td);

		//selection sort
		long startTime1 = System.nanoTime();
		ss.sort();
		long endTime1 = System.nanoTime();
		long td1 = System.nanoTime()-startTime1;
		System.out.println("Selection sort time is " + td1);

		//mergesort
		String[] temp = null;
		long startTime3 = System.nanoTime();
		merge.Sort(stockArr3);
		long endTime3 = System.nanoTime();
		long td3 = System.nanoTime()-startTime3;
		System.out.println("Merge sort time is " + td3);

		//quicksort
		long startTime2 = System.nanoTime();
		qs.qsort(stockArr2, 0, stockArr2.length-1);
		long endTime2 = System.nanoTime();
		long td2 = System.nanoTime()-startTime2;
		System.out.println("Quick sort time is " + td2);


	}
}
