import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Hashtable;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Lab10_1_GUI
{
	public static void main (String[] args)
	{

		JFrame frame = new JFrame ("GUI Search Hashtable");

		frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().add(new HashGuiPanel());
		frame.pack();
		frame.setVisible(true);

	}
}

class HashGuiPanel extends JPanel
{
	Hashtable<String,String> HT = new Hashtable<String,String>();
	private final HashFieldPanel  firstPanel, secondPanel, thirdPanel, fourthPanel,fifthPanel;
	private final JLabel resultLabel;
	private final JButton button,searchbutton;

	//-----------------------------------------------------------------
	//  Constructor: Sets up the main GUI components.
	//-----------------------------------------------------------------
	public HashGuiPanel()
	{
		//input options
		firstPanel = new HashFieldPanel("Enter First Word ", 30);
		secondPanel = new HashFieldPanel("Enter Second Word", 30);
		thirdPanel = new HashFieldPanel("Enter Third Word", 30);
		fourthPanel = new HashFieldPanel("Enter Fourth Word", 30);
		fifthPanel = new HashFieldPanel("Search",30);

		resultLabel = new JLabel ("");

		button = new JButton("Enter");
		searchbutton = new JButton("Search");
		button.addActionListener(new SendListener());
		searchbutton.addActionListener(new search());

		add(firstPanel);
		add(secondPanel);
		add(thirdPanel);
		add(fourthPanel);
		add(button);
		add(fifthPanel);
		add(searchbutton);
		add(resultLabel);



		setPreferredSize (new Dimension(550, 400));
		setBackground (Color.LIGHT_GRAY);
	}

	//*****************************************************************
	//  Represents an action listener for the send button.
	//*****************************************************************
	private class SendListener implements ActionListener
	{

		@Override
		public void actionPerformed (ActionEvent event)
		{

			HT.put("1", firstPanel.getFieldText());
			HT.put("2", secondPanel.getFieldText());
			HT.put("3", thirdPanel.getFieldText());
			HT.put("4", fourthPanel.getFieldText());

		}
	}
	private class search implements ActionListener
	{
		@Override
		public void actionPerformed (ActionEvent event)
		{
			boolean n =HT.containsValue(fifthPanel.getFieldText());
			if (n == true)
			{
				resultLabel.setText("found");
			}
			else
			{
				resultLabel.setText("not found");
			}
		}
	}
}

class HashFieldPanel extends JPanel
{
	private final JLabel lab;
	private final JTextField field;

	//-----------------------------------------------------------------
	//  Constructor: Sets up the field and label combination.
	//-----------------------------------------------------------------
	public HashFieldPanel(String labText, int fieldLength)
	{
		lab = new JLabel(labText);
		field = new JTextField(fieldLength);

		add(lab);
		add(field);

		setPreferredSize (new Dimension(500, 60));
		setBackground (Color.LIGHT_GRAY);
	}

	//--------------------------------------------------------------
	//  Prints the field information to standard output.
	//--------------------------------------------------------------
	public String getFieldText()
	{
		return field.getText();
	}
}