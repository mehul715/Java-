import java.util.Random;

public class lab10_2
{
	public static void main(String[] args)
	{
		HashTable<String, String> hTable = new HashTable<>(128);
		HashFunction hash = new HashFunction();
		String word ;
		int count = 0;
		boolean flag =true;
		int threshold = (int)(128*0.6);
		hTable.setCol(0);
		//calculate till it reaches 60% of the table
		while(count < threshold)
		{
			word = "";
			for (int i = 0; i < 8; i++)
				word = word + randomString();
			int pos = hash.sfold(word, 128);
			if(hTable.hashInsert(pos, word, word));
			count ++;
			//System.out.println(word + " is a duplicate Key");
			if ((count/128.0 > 0.4)&& flag)
			{
				System.out.println("Slot count is "+ count+" & table is ["+(((count/128.0)*100))+"%] full. The number of collision is " + hTable.getCol());
				flag = false;
			}
		}
		System.out.print("The number of collition is "+ hTable.getCol()+ " and Table is [" + ((count/128.0)*100) +"%] full");
	}
	public static String randomString()
	{
		String chars = "1234567890";
		StringBuilder strngBuilder = new StringBuilder();
		Random rnd = new Random();
		while (strngBuilder.length() < 1)
		{
			int index = (int) (rnd.nextFloat() * chars.length());
			strngBuilder.append(chars.charAt(index));
		}
		String output= strngBuilder.toString();
		return output;

	}
}