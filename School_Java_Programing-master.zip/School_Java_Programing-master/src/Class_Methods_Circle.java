


import java.text.DecimalFormat;
public class Class_Methods_Circle {
	
		public static void main (String arg[]){
			
			Circle c4=new Circle(2.0);
			c4.setRadius(2.0);
			
			System.out.println("radius is : " + c4.getRadius());
			
			Circle c2=new Circle(2.0);
			//System.out.println(c2.toString()); //explicit call
			System.out.println(c2);//implicit call
			
			DecimalFormat x1 =new DecimalFormat("0.##");
			Circle c3=new Circle(2.0);
			c3.getArea();
			System.out.println("Area = " + x1.format(c3.getArea()));
			
			DecimalFormat x2 =new DecimalFormat("0.##");
			Circle c5=new Circle(2.0);
			c4.circumference();
			System.out.println("Circumference = " + x2.format(c4.circumference()));
			
		}
	}




	class Circle {
		// private instance variable, not accessible from outside this class
		private double radius; 
		
		
		// constructor has similar name as class
		public Circle(double r){
			radius = r;
		}
		// Is there a need to change the values of radius 
		//of a Circle instance after it is constructed? If so, add two public methods called 
		//setters for changing the radius of a Circle instance as follows:
		public void setRadius(double newRadius) { 
			radius = newRadius;
		}
		
		// A public method for retrieving the radius
		//getRadius , R is capital .. it take value of radius and returns it
		public double getRadius() {
			return radius; 
		}
		// A public method for computing the area of circle
		public double getArea(){
			return radius*radius*Math.PI;
		}
		// A public method for computing the circumference of circle
		public double circumference(){
			return radius*2*Math.PI;
		}
		
		public String toString(){
			return "Circle[radius=" + radius + "]";
					
			
			
		}
	}


