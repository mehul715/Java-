
import java.util.Arrays;
import java.util.Random;
public class Array_Reverese_rows {
	
	/*
	 *     (1) Write a program 
�	to create a 2x10 two dimensional integer array.
�	use Math.random() from java.util.Random to generate 20 integer numbers from 100 to 1000
�	store each random number in the two dimensional array.
�	At the end, print the array. Then switch numbers between two rows then print the array again.

	 */
	/*Row 0
466 531 629 116 435 714 328 781 238 311 
Row 1
231 840 755 972 418 241 219 609 478 901 
Switch row 
Row 0
231 840 755 972 418 241 219 609 478 901 
Row 1
466 531 629 116 435 714 328 781 238 311
*/
	
	public static void main(String[] arg){
	  
		
	  int [][] array=new  int[2][10];//assigning 2x10 two dimensional array
	  Random random = new Random();

        
      for( int i = 0 ; i < array.length ; i++ ){ 
         for ( int j = 0 ; j < array[i].length ; j++ ){ 
            array[i][j] = (int) (Math.random()*901+ 100);
          }
       }

     
      //Print Array
      for( int[] a : array ){ 
          System.out.println( Arrays.toString( a ));
      }
      
      
       
      //To switch rows 
      int temporory_Array[] = array[0]; 
      array[0]=array[1];
      array[1]=temporory_Array;
      
      
      System.out.println("\n");
      System.out.println("Switched Rows:");
      
      
   
      //Reprinting Array
      for(int[] a:array){
    	  System.out.println(Arrays.toString(a));	   
      }
      
      
  }
}



