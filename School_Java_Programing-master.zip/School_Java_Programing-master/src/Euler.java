

import java.util.Random;
public class Euler {


public static void main(String args[]) {
    int total = 0;
    for ( int i = 0; i < 1000; i++ ) {
        if ( i % 3 == 0 || i % 5 == 0 ) {
            System.out.println( " X: " + i );
            total = total + i;
        }
    }
    System.out.println( "\nTotal: " + total );
    
    Random randomGen=new Random();
    double x1 = randomGen.nextDouble() * 2 - 1.0;
    System.out.println("Random = " + x1);
}


} 

