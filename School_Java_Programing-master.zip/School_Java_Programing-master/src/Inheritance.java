



/*Arithmetic progression with default increment: 
0 1 2 3 4 5 6 7 8 9
Arithmetic progression with increment 5 : 
0 5 10 15 20 25 30 35 40 45
Arithmetic progression with increment 10 : 
0 10 20 30 40 50 60 70 80 90
Geometric progression with default base: 
1 2 4 8 16 32 64 128 256 512
Geometric progression with base 3: 
1 3 9 27 81 243 729 2187 6561 19683
Geometric progression with base 5 : 
1 5 25 125 625 3125 15625 78125 390625 1953125
*/
public class Inheritance {

	//********************************************************************
	//Driver   
	//
	//********************************************************************
	public static void main (String[] args){
		
		arithmetic a = new arithmetic(0,0);
		a.printProgression(10);
		a.setinc(5);
		a.printProgression(10);
		a.setinc(10);
		a.printProgression(10);
		
		geometric g = new geometric(1,0);
		g.setbase(2);
		g.printProgression(10);
		g.setbase(3);
		g.printProgression(10);
		g.setbase(5);
		g.printProgression(10);
		
		
		
	}
}

//********************************************************************
//Parent Class Progression  
//
//********************************************************************
class Progression {

	int first;//variable that methods can access
    int cur;//varaible that methods can access
    int increment = 1; // by default
    int base = 0;  // by default
    
	public Progression(int i, int j){ //parameters
	
    first = i; //Initialization
    cur=j; // initialization
	}
	
    public int firstValue(){
    	cur = first;
    	return cur;
    }
  
    public int nextValue(){
    	return cur+=increment;
    }
    
    public void printProgression(int n){
    	
    	if(getClass().getSimpleName() == "geometric")
    		System.out.printf("Geometric progression with base %d: \n", base);
    	else if (getClass().getSimpleName() == "arithmetic")
    		System.out.printf("Arithmetic progression with increment %d: \n", increment );
    	
    	System.out.print(firstValue());
    	
    	for (int i = 0; i< n-1; i++){
    		System.out.printf(" %d",nextValue());
    	}
    	System.out.println();
    }
	
}

//********************************************************************
//Child Class - geometric   
//Note: Overriding the parent class Nextvalue method
//********************************************************************
class geometric extends Progression {
	
	
	public geometric(int i, int j){
		super(i, j);
		base = 1;
	}
	
	void setbase(int i){
		base =  i;
	}
	
	public int nextValue(){
		return cur*=base;
	}

}

//********************************************************************
//child class- arithmetic   
//
//********************************************************************

 class arithmetic extends Progression {
	
	public arithmetic(int i, int j){
		super(i , j);
	}
	
	void setinc(int i){
		super.increment =  i;
	}
	

}


