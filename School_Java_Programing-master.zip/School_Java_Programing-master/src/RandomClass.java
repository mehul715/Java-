

import java.util.Random;
public class RandomClass {

	public static void main(String[] args){

		Random gen =new Random();
		
		int num1= gen.nextInt();
		System.out.println("A random integer: " + num1 );
		/*
		 * A random integer: 577254581
		 */
		
		
		int num2=gen.nextInt(10);
		System.out.println("From 0 to 9:" + num2);
		/*
		 * From 0 to 9:6
		 */
		
		int num3 = gen.nextInt(10)+1;
		System.out.println("From 1 to 10:" + num3);
		
		/*
		 * From 1 to 10: 9
		 */
		
		
		int num4 = gen.nextInt(15)+20;
		System.out.println("From 20 to 34:" + num4);
		
		int num5 = gen.nextInt(2)-1;
		System.out.println("Gfdsd:" + num5);
		
	}
		
	}

