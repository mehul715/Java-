
import java.util.Scanner;
public class WrapperClass {

	
	public static void main (String[] args){
		
		Scanner input = new Scanner(System.in);
		
		String myString="12345";
		int a =100;
		
		System.out.println(myString + a);
		
		/*prints  12345100
		 * 
		 */
		int b = Integer.parseInt(myString);
		System.out.println(" sum is " +(b + a)); // now that works ! Changing value of string 
		
		
	}
}
