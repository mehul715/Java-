

public class stringRepeat {
 public static void main(String arg[]){
	String str = "character";
	
	int count = 0;
	for(int i =0; i<str.length(); i++){
	
		if (str.charAt(i)=='a'){
			
			count++;
			
		}
		
		
	   }	
		System.out.println("count a " + count);
	}
	
}
