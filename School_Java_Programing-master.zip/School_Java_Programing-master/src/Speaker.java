

public interface Speaker
{
   public abstract void speak();
   public abstract void announce (String str);
}