


import java.util.Scanner;


public class Polymorphism {
	public static void main(String[] args){
		String name, team, movie;
		Scanner scan=new Scanner(System.in);
		
		Speaker obj = new SpeakerOfTheHouse();
		Speaker obj2=new SportsAnnouncer();
		Speaker obj3=new Actor();
		
		System.out.println("Enter the name of a bill:");
		System.out.println("Enter the name of a sports team:");
		System.out.println("Enter the name of a movie:");
		
		name = scan.nextLine();
		team = scan.nextLine();
		movie = scan.nextLine();
		
		obj.speak();
		obj.announce(name);
		
		obj2.speak();
		obj2.announce(team);
		
		obj3.speak();
		obj3.announce(movie);
		
	}


}

 
//********************************************************************
//SpeakerOftheHouse Class  
//
//********************************************************************
 class SpeakerOfTheHouse implements Speaker{

	public void speak() {
		System.out.println("I am Speaker of the House");
	
	}

	public void announce(String str) {
		System.out.println("The " + str + " has passed!");
		
	}
 }
 
 
//********************************************************************
//SportsAnnounc**************************************************************
class SportsAnnouncer implements Speaker{

	public void speak() {
		System.out.println("Goal!");
	
	}

	public void announce(String str) {
		System.out.println("The" + str + " have scored a goal!");
		
	}
}


//********************************************************************
//Actor Class  
//
//********************************************************************
class Actor implements Speaker{

	public void speak() {
		System.out.println("I've been nominated for three Academy Awards");
	
	}

	public void announce(String str) {
		System.out.println("I'm currently staring in "+ str);
		
	}
}