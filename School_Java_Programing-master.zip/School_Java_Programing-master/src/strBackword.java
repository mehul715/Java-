

public class strBackword {

	public static void main (String arg[]){
		
		/*
		 * write a code fragment the prints the character stored in string called str backward.
		 */
		String str = "character";
		
		for(int i = str.length()-1; i>=0; i--){
			
			
			System.out.println(str.charAt(i) + " ");
		}
		
	}
	
	
}
