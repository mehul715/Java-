package List3;

import java.util.ArrayList;
import java.util.*;
public class Staffdriver {

	
	
	public static void main(String[] args)
	{
      
	//Staff personnel = new Staff();
	//personnel.payday();
	
 
      
        Staff staff = new Staff();
        //staff.payday();
        for (int i = 0; i < staff.getSize(); i++) {
            list.add(staff.getStaff(i));
            System.out.println( list.get(i));
            //print the type
            if (list.get(i) instanceof Volunteer) {
                System.out.println("Employment Type: Volunteer");
            } else if (list.get(i) instanceof Hourly) {
                System.out.println("Employment Type: Hourly Employee");
            } else if (list.get(i) instanceof Executive) {
                System.out.println("Employment Type: Executive Employee");
            } else if (list.get(i) instanceof Employee) {
                System.out.println("Employment Type: Employee");
            }
            //print payment
            System.out.println("Pay Off: $" + list.get(i).pay());
            System.out.println("");
        }
        System.out.println("-------");
        
        Scanner input = new Scanner(System.in);
       
        while (true) {
            
            if (list.isEmpty()) {
                break;
            }
            System.out.println("Enter employee's name to delete (enter 0 to terminate): ");
            String name = input.next();
            
            if (name.equals("0")) {
                break;
            }
            boolean wrong = false;
            for (StaffMember staffMember : list) {
                if (name.equals(staffMember.name)) {
                    if (staffMember instanceof Executive) {
                        System.out.println("Executive record hasn't approved permission to delete.");
                        wrong = true;
                        break;
                    } else {
                        list.remove(staffMember);
                        wrong = true;
                     
                        System.out.println("Search deleted successfully.");
                        break;
                    }
                }
            }
            
            if (!wrong) {
                System.out.println("Search not found!");
            }
            System.out.println("");
        }
        System.out.println("--------");
        
        while (true) {
            
            System.out.println("Enter name to change or update the address.(0 to terminate): ");
            String name = input.next();

            if (name.equals("0")) {
                break;
            }
                
            boolean notright = false;
            for (StaffMember staffMember : list) {
                
                if (name.equals(staffMember.name)) {
                    System.out.println("Enter new Address: ");
                    input.nextLine();
                    staffMember.address = input.nextLine();
                    notright = true;
                    break;
                }
            }
            
            if (!notright) {
                System.out.println("Search not found!.");
            }
            System.out.println("");
        }
        System.out.println("-----------");
        System.out.println("Below is the Final List.");
        System.out.println("");
       
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
            
            if (list.get(i) instanceof Volunteer) {
                System.out.println("Employment Type: Volunteer");
            } else if (list.get(i) instanceof Hourly) {
                System.out.println("Employment Type: Hourly Employee");
            } else if (list.get(i) instanceof Executive) {
                System.out.println("Employment Type: Executive Employee");
            } else if (list.get(i) instanceof Employee) {
                System.out.println("Employment Type: Employee");
            }
            
            System.out.println("Pay Off: $" + list.get(i).pay());
            System.out.println("");
        }
    }
}