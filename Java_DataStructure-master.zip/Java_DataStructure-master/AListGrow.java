

public class AListGrow extends AList{
         public AListGrow(int i){
        	 
         }
        	 public void expand(int listSize){
        		 
        		 super.expand(listSize);
        	 }
         }
			
		
		
		

	




