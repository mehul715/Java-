import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Stack;
import java.util.StringTokenizer;

/*
 * (b)	Using java.util.Stack and java.util.StringTokenizer to write a java program to validate and
 * calculate postfix expression from the input data file
 *  - postfix.dat
 */

public class problem5b_final {
	public static void main(String[] args) throws Exception {

		FileReader file = new FileReader("postfix.dat");
		@SuppressWarnings("resource")
		BufferedReader br = new BufferedReader(file);
		String line = null;
		while ((line = br.readLine()) != null) {
			System.out.println(line);
			try
			{
				System.out.println("= "+postEval(line) + "\n");
				System.out.println("===============================");
			}
			catch(Exception e1)
			{
				System.out.println("invalid expression  \n");
				System.out.println("===============================");
			}
		}
	}

	public static int postEval(String exp) {
		Stack<Integer> s = new Stack<Integer> ();
		StringTokenizer st = new StringTokenizer(exp);

		while (st.hasMoreTokens()) {
			String tok = st.nextToken();

			//if its digit push it to stack s.
			if (Character.isDigit(tok.charAt(0))){
				int digit= Integer.parseInt(tok);
				s.push(digit);
				//System.out.println(s.push(digit));
			} else{
				//else perform the calculations if it is +,-,/ and *
				int operand2 = s.pop();
				int operand1 = s.pop();
				String operator = tok.toString();



				if (operator.equals("+")) {
					s.push(operand1 + operand2);
				} else if (operator.equals("-")) {
					s.push(operand1 - operand2);
				} else if (operator.equals("*")) {
					s.push(operand1 * operand2);
				} else if (operator.equals("/") && operand2!=0){
					s.push(operand1 / operand2);


				}
				else{
					System.out.println("\n");

				}

			}
		}
		return s.pop();
	}
}