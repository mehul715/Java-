import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Stack;
/*
 * (a)	Using java.util.pile to write a java program to
 * validate and calculate the result of each arithmetic Expression from input file (infix.txt).
 * All equations from the input file are in traditional infix notation. Display each expression first.
 * Then, if the arithmetic expression is not valid, display �Invalid expression � message otherwise
 * display the result of the calculation.
 */
public class homework5a_final {
	//static pile stock = new pile();
	public static void main(String[] args) throws Exception
	{

		FileReader file = new FileReader("infix.dat");
		BufferedReader br = new BufferedReader(file);
		String line = null;
		while ((line = br.readLine()) != null) {
			System.out.println(line);
			String a= checkc(line);

			try
			{
				//to print postfix expression
				//System.out.println(a);
				System.out.println("=" + EvalPost(a)+ "\n");
				System.out.println("===============================");
			}
			catch(Exception e1)
			{
				System.out.println("invalid expression \n");
				System.out.println("===============================");
			}

		}
	}

	public static String checkc(String inf)
	{
		//ArrayList<String>keeper = new ArrayList<String>()
		Stack<Character> pile = new Stack<>();
		StringBuilder string = new StringBuilder();
		char[] c = inf.toCharArray();
		for (int i = 0; i < c.length; i++)
		{
			if ((c[i] >= '0') && (c[i] <= '9')) //checking for digits
			{
				string.append(c[i]);           // if there are then append it to string
			}

			else if (c[i] == '(')           //checking for open '('
			{
				pile.push(c[i]);           // if it is then push into pile
			}

			//checking for operators
			else if ((c[i] == '*') || (c[i] == '+') || (c[i] == '-') || (c[i] == '/'))
			{
				while ((!pile.empty()) && precedence(c[i]) <= precedence(pile.peek()) && (pile.peek() != '('))  // check until pile is  empty and peek char is not '('
				{
					string.append(pile.pop());
				}

				pile.push(c[i]);                                              //finally push the char ..if while is false(if it doesnt needs to be check for precedence)
			}//end of checking operators

			else if (c[i] == ')')                                              //check for ')'
			{
				while ((!pile.empty()) && (pile.peek() != '('))             // loop through it till pile is not empty and peek is not '('
				{
					string.append(pile.pop());
				}
				if (!pile.empty())
					pile.pop(); // popping out the left brace ')'
			}//end of closing brackets

		}
		while (!pile.empty())
		{
			string.append(pile.pop()); // pop whole pile and append all the values to string

		}
		return string.toString();
	}

	// evaluating postfix coming from infix function
	public static int EvalPost(String string)
	{
		Stack<Integer> s = new Stack<Integer>();
		char[] c = string.toCharArray();

		//checking for open and close brackets in character if it does..exit out from loop.
		for (int i = 0; i < string.length(); i++){
			if (c[i]=='(' || c[i]==')' )
			{
				System.out.println("invalid expresion");
				System.exit(1);
			}
		}
		for (int i = 0; i < string.length(); i++)
		{

			if ((c[i] == '*') || (c[i] == '+') || (c[i] == '-') || (c[i] == '/'))
			{
				int calcu = calculate(s.pop(), s.pop(), c[i]);
				s.push(calcu);
			}
			else if ((c[i] >= '0') || (c[i] <= '9'))
			{
				s.push(c[i] - '0');
			}

		}
		return s.pop();
	}


	private static int calculate(int pop1, int pop2, char chars)
	{
		switch (chars)
		{
		case '+':
			return pop2 + pop1;
		case '-':
			return pop2 - pop1;
		case '*':
			return pop2 * pop1;
		case '/':
			return pop2 / pop1;
		default:
			return 0;
		}
	}
	//  precedence checker
	static int precedence(char opers)
	{
		if (opers == '+' || opers== '-')
			return 1;
		if (opers == '*' ||opers == '/' || opers == '%')
			return 2;
		return 0;
	}
}



