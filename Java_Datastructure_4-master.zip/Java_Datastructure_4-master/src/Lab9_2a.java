import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Scanner;

public class Lab9_2a {
	/*

(2)	Objective: java Priority queue with customized comparator.

(a)	Min-Heap (1 point)
Hospital emergency room assign patient priority base on symptom of the patient.
Each patient receives an identity number which prioritizes the order of emergency for the patient.
The lower the number is, the higher the emergency will be.
Use java.util.PriorityQueue to write a java program to create the emergency room registration database.
The patient.txt is the input file for patient record. Download patient.txt,
 Patient.java from Moodle to perform following specifications:
(i)	Load all records from the input file.
(ii)At the end, print the list in assigned priority order.


	 */
	public static void main(String[] args) throws IOException {
		BufferedReader br =new BufferedReader(new FileReader ("patient.txt"));
		Scanner scan = new Scanner(System.in);
		@SuppressWarnings("unchecked")
		emergency inx = new emergency();
		PriorityQueue<Patient>pQueue = new PriorityQueue<Patient>(8,inx);
		String line=null;
		while((line=br.readLine())!=null)
		{
			String[] lineSplit=line.split(",");
			Patient pp = new Patient(Integer.parseInt(lineSplit[0]), lineSplit[1], lineSplit[2]);
			pQueue.add(pp);
		}
		br.close();
		System.out.println("emergency by ID # is below \n");
		while(!pQueue.isEmpty())
		{
			System.out.println(pQueue.remove());
		}
	}
}
class emergency implements Comparator<Object>{
	@Override
	public int compare(Object o1, Object o2) {
		Patient a1 =(Patient)o1;
		Patient a2=(Patient)o2;
		return Integer.compare(a1.getId(),a2.getId());
	}
}
