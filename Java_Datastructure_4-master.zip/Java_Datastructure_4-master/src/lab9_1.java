import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collections;
import java.util.PriorityQueue;
import java.util.Scanner;

public class lab9_1 {
	/*
	 * (1)	Objective: Maxheap priority queue (1 points)
Download inventory.txt, MaxHeap.java

Write the main java program to read all records from inventory.txt to build a Maxheap Queue using MaxHeap.java.
At the end, remove the Max from Maxheap queue and print the Maxheap. The order of the priority is the string value of the input records

	 */
	public static void main(String[] args) throws IOException {
		BufferedReader br =new BufferedReader(new FileReader ("inventory.txt"));
		Scanner scan = new Scanner(System.in);
		@SuppressWarnings("unchecked")

		//ArrayList<String> lines = new ArrayList<String>();
		PriorityQueue<String>pq = new PriorityQueue<String>(10,Collections.reverseOrder());
		String line=null;

		System.out.println("records from file");
		while((line=br.readLine())!=null)
		{
			System.out.println("input record :" +line);
			pq.add(line);
		}
		br.close();
		System.out.println("\nMax Heap is :");
		while(true)
		{

			for (int i =0; i<pq.size(); i++){

				System.out.println(pq.poll());
			}
		}

	}

}
