import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Scanner;


public class lab9_2b {
	/*
	 * (b)	Max-Heap (2 points)
Use the inventoryNew.txt as input file to build a Max-Heap (java PriorityQueue).
The order of the priority queue is the reverse order of part number. At the end,
print the Max-Heap in iterator order and then print the same Max-Heap in priority queue order.
Download Inventory.java and inventoryNew.txt from Moodle.

	 */
	public static void main(String[] args) throws IOException {
		BufferedReader br =new BufferedReader(new FileReader ("inventoryNew.txt"));
		List<Inventory> listy = new ArrayList<Inventory>();
		Scanner scan = new Scanner(System.in);
		@SuppressWarnings("unchecked")
		partCompare inx = new partCompare();
		Queue<Inventory>pQueue = new PriorityQueue<Inventory>(10,inx);
		String line=null;
		while((line=br.readLine())!=null)
		{
			Inventory inV = new Inventory();
			String[] lineSplit=line.split(",");
			inV.SetInventory(lineSplit[0], lineSplit[1], lineSplit[2], Double.parseDouble(lineSplit[3]));
			pQueue.add(inV);
		}
		br.close();
		Iterator it = pQueue.iterator();
		System.out.println("MaxHeap in iterator order :");
		System.out.println("=========================");
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		System.out.println("==================================================");
		System.out.println("Max Heap in Priority Order:");
		System.out.println("==================================================");
		while(!pQueue.isEmpty())
		{
			System.out.println(pQueue.remove());
		}
	}
}
class partCompare implements Comparator<Object>{
	@Override
	public int compare(Object o1, Object o2) {
		Inventory a1 =(Inventory)o1;
		Inventory a2=(Inventory)o2;
		return a2.getPartNo().compareTo(a1.getPartNo());
	}
}
