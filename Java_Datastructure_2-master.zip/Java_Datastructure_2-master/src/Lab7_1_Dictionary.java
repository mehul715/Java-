/*
 * (1)	Objective: Multiple Dictionaries for data structure (1 points)
Use UALdictionary.java to create two Dictionaries and allows user to access the employee record by Key of
different dictionary. Value/content for the KVpair will be Staffmember object. The employee.txt is the input file
 that contains data records of all employee.
(a)	Dictionary 1:  will use SSN field which is the fourth field of the data field on the record as Key.
(b)	Dictionary 2: will use Name field which is the first field of the data field on the record as Key.
Download StaffMember.java, UALdictionary.java, Alist.java, List.java, Dictionary.java, KVpair.java and employee.txt from Moodle.

 */

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
public class Lab7_1_Dictionary {

	static Map<String,StaffMember>dictionary1=new HashMap<>();
	static Map<String,StaffMember>dictionary2=new HashMap<>();
	public static void main(String[] args) throws Exception{
		addThemAll();
	}
	public static void addThemAll() throws Exception
	{
		FileReader file = new FileReader("employee.txt");
		BufferedReader br = new BufferedReader(file);

		String line = null;
		while ((line = br.readLine()) != null)
		{
			StaffMember staff = new StaffMember();
			String[] lineSplit = line.split(",");
			//Double rate1=Double.parseDouble(lineSplit[4]);
			staff.SetStaffMember(lineSplit[0], lineSplit[1], lineSplit[2], lineSplit[3], Double.parseDouble(lineSplit[4]));
			dictionary1.put(lineSplit[3], staff);
			//System.out.println(dictionary1.toString());
			dictionary2.put(lineSplit[0], staff);
		}//end of while loop

		Scanner scan= new Scanner(System.in);
		System.out.println("Enter SSN or Name you want to search, type quit to quit");
		String key=scan.nextLine();
		while(!key.equals("quit"))
		{
			if(dictionary1.containsKey(key))
				System.out.println(dictionary1.get(key)+ "\n");
			else if(dictionary2.containsKey(key))
				System.out.println(dictionary2.get(key)+ "\n");
			else
				System.out.println("\nEntered wrong SSN, try again");
			System.out.println("Enter SSN you want to search, type quit to quit");
			key=scan.nextLine();
		}


	}


}//end of class


