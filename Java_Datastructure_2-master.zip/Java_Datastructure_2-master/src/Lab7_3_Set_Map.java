import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class Lab7_3_Set_Map {
	static ArrayList<String> s = new ArrayList<String>();

	public static void main(String[] args) throws Exception {
		String input;
		FileReader file = new FileReader("employee.txt");
		BufferedReader br = new BufferedReader(file);

		String line = null;
		while ((line = br.readLine()) != null)
		{
			StaffMember staff = new StaffMember();
			String[] lineSplit = line.split(",");
			Double rate1=Double.parseDouble(lineSplit[4]);
			staff.SetStaffMember(lineSplit[0], lineSplit[1], lineSplit[2], lineSplit[3], rate1);

			//saving it by name
			s.add(lineSplit[0]);

		}//end of while loop

		TreeSet<String> dictNary = new TreeSet<String>(s);
		System.out.println("Current Names in Dictionary : " + dictNary);
		System.out.println("=================================================================================");
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a name you want to access (type x to quit):  ");
		input = sc.nextLine();
		while (!input.equalsIgnoreCase("x")) {

			System.out.println();
			if (input.length() < 1)
				continue;


			try {
				Iterator<String> looper = dictNary.iterator();
				String theKey = null;
				int i = 0;
				if (input.length() < 1)
					continue;
				else if (input.toLowerCase().charAt(0) == 'x')
					break;
				while (looper.hasNext()) {
					theKey = looper.next();
					i++;
					if (theKey.startsWith(input)) {
						System.out.println("Employee found");
						System.out.print("Remove Employee from the employee records, type Y or N:  ");
						break;
					} else {
						if (i == dictNary.size() && !theKey.startsWith(input)) {
							System.out.println("Sorry! Employee was not found with that name");
							System.out.println("type anything to Continue");
						}
					}

				}//end of while loop
				String confirm;
				do {
					confirm = sc.nextLine();
				} while (confirm.length() < 1);

				if (confirm.toUpperCase().charAt(0) == 'Y') {
					dictNary.remove(input);
					System.out.println("Employee has been removed.");
				}
			} catch (NullPointerException e) {
				System.out.println("Employee not found....");
			}
			System.out.println();
			/*if (dictNary.size() < 1) {
				System.out.println("No more employees left");
				break;
			}*/
			System.out.print("Enter a name you want to access (type q to quit):  ");
			input = sc.nextLine();

		}

	}
}
