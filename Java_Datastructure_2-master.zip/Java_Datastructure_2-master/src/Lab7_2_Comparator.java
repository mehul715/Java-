import java.util.Comparator;
import java.util.Scanner;


/*
 * (2)	Objective: Implement java.util.Comparator to determine the order/match of arbitrary objects.
Write a java program to determine the order of two shape objects by comparing their area. For example: determine the order of
(a)	A 20x5 rectangular.
(b)	A circle with g2ius 6.

Allow user to input length & width for the rectangular and g2ius for the circle to test your program. Download Circle.java,
 Rectangular.java and Shape.java from Moodle.

 */
public class Lab7_2_Comparator {


	public static void main(String[] args) {
		int length, width, g2ius;
		double pi;
		int r;



		Scanner scan= new Scanner(System.in);
		System.out.println("Enter the Length of the rectangle");
		length=scan.nextInt();
		System.out.println("Enter the Width of the rectangle");
		width=scan.nextInt();
		System.out.println("Enter the Radius of the circle");
		r=scan.nextInt();


		Shape xx = new Rectangle(length,width);
		System.out.println("Area of Rectangle is " + xx.computeArea());
		System.out.println("Perimeter of Rectangle is " + xx.computePerimeter());

		Shape yy = new Circle(r);
		System.out.println("Area of radius is " + yy.computeArea());
		System.out.println("Perimeter of radius is " + yy.computePerimeter());

		System.out.println("\nAfter reviewing both Area and Perimeter \n");
		Shape tan= x(xx , yy, new ShapeComparator());


		if(tan ==xx)
		{
			System.out.println("Rectangle has larger area");
		}
		else {
			System.out.println("Circle has larger area");
		}
		System.out.println("The area is " + tan.computeArea() + "\n");

		////////////////////Checking for Perimeter part ////////////////////////////////
		tan= x1(xx , yy, new peri_ShapeComparator());
		if(tan ==xx)
		{
			System.out.println("Rectangle has larger perimeter");}
		else {
			System.out.println("Circle has larger perimeter");
		}
		System.out.println("The Permiter is " + tan.computePerimeter());

	}//end of main


	public static Shape  x(Shape g1, Shape g2, Comparator<Shape>c){
		if(c.compare(g1,g2)>0)
			return g1;
		else
			return g2;
	}

	public static Shape x1(Shape g1, Shape g2, Comparator<Shape>c){

		if(c.compare(g1,g2)>0)
			return g1;
		else
			return g2;
	}
}//end of class


class ShapeComparator implements Comparator<Shape> {

	@Override
	public int compare(Shape o1, Shape o2) {
		double area1 = o1.computeArea();
		double area2 = o2.computeArea();

		if (area1>area2)
			return 1;
		else if ( area1==area2)
			return 0;
		else
			return -1;
	}

}

class peri_ShapeComparator implements Comparator<Shape> {
	@Override
	public int compare(Shape o1, Shape o2) {
		double area1 = o1.computePerimeter();
		double area2 = o2.computePerimeter();

		if (area1>area2)
			return 1;
		else if ( area1==area2)
			return 0;
		else
			return -1;
	}

}
