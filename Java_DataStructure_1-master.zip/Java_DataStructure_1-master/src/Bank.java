
public class Bank {

}
