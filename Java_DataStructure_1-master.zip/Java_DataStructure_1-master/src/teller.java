import java.util.LinkedList;

public class teller {

	static LinkedList<Integer> tellerQ = new LinkedList<Integer>();


	int size;

	public teller(int size) {
		for(int i=0; i<size; i++) {
			tellerQ.add(i + 1);
		}
		this.size = size;
	}
	/*
	public void assignT(int tel_id,  Customer cust) {
		tellerQ.add(tel_id);

		System.out.println(cust.toString() + " joins the line," + cust.toString() + "is being served" );
	}
	 */
	public int getT(){
		if(!tellerQ.isEmpty()){
			return tellerQ.remove();
		}
		else if(tellerQ.size()==2){
			return 2;

		}
		return 1;
	}


	public boolean isSize() {
		return tellerQ.size() == size;
	}
}
