import java.util.LinkedList;
import java.util.Queue;

public class TicketCounter
{

	public static void main ( String[] args)
	{
     	int time;
		int averageT;
		int leaving;
		TicketBuyer tix;
		Queue<TicketBuyer> line = new LinkedList<TicketBuyer>();

		int[] numC = new int[10];

		int currCash =0;
		while(currCash<10){
			for (int i=0; i < currCash; i++)
				numC[i] = 0;
			for (int j=1; j <= 100; j++)
				line.add((new TicketBuyer(j*15)));
			time = 0;
			while ((line.size()!=0)){
				int k =0;
				while(k <= currCash){
					if ((line.size()!=0)){
						tix = line.remove();
						if (numC[k]< tix.getArrivalTime())
							leaving = tix.getArrivalTime() + 120;
						else
							leaving = numC[k] + 120;
						tix.setDepartureTime (leaving);
						numC[k] = leaving;
						time += tix.totalTime();}
				}

			}//end of while loop


			averageT = (time / 100);
			System.out.println ("Number of cash: " + (currCash+1));
			System.out.println ("Average time: " + averageT + "\n");

			currCash++;
		}
	}
}

