import java.util.LinkedList;


public class lab6a_try {
	static Line line = new Line();
	static LinkedList<Integer>tic =new LinkedList<Integer>();
	static int custCurrent=0;
	static int CYCLES =10;


	public static void main(String[] args) {
		simpleSimulation(10);
	}



	public static void simpleSimulation(int Cycles){
		for(int i=0 ; i<CYCLES ; i++)
		{
			int numbsOfcust= (int)(Math.random()*5 +1);


			for(int j=1; j<=numbsOfcust; j++)
			{
				if(tic.add(custCurrent))
					try{
						System.out.println("Ticket Buyer #" + custCurrent + " joined the line!");
						custCurrent++;
						Thread.sleep(15000);
					}
				catch (Exception e) {
					System.out.println(e);
				}


			}


			//available attendant to help
			int attendantAvailable = (int) (Math.random()*4+1);

			for (int z =1; z<=4; z++)
			{


				if((tic.size()>0) && z<=attendantAvailable)
				{
					try{
						int g= tic.getFirst();
						System.out.println(g + " # is getting helped by the attendant, " + "There are " + (tic.size()-1) + " Ticket Buyers waiting in the line!");

						tic.removeFirst();
						Thread.sleep(120000);
					}
					catch (Exception e) {
						System.out.println(e);
					}


				}
			}//end of attendant loop

			if(tic.isEmpty())
			{
				try {
					// thread to sleep for 1000 milliseconds
					Thread.sleep(1000);
				} catch (Exception e) {
					System.out.println(e);
				}
				System.out.println("attendants are waiting....");

			}






		}
		tic.clear();

		System.out.println("\n Show is about to start. Line is Empty!");

	}

}
