import java.util.LinkedList;
import java.util.Queue;

public class Lab6_1{


	static Line line = new Line();
	static Queue<Integer>tel =new LinkedList<Integer>();
	static int custCurrent=0;
	static int CYCLES =10;


	public static void main(String[] args) {
		simpleSimulation(10);
	}//end of main function



	public static void simpleSimulation(int Cycles){
		for(int i=0 ; i<CYCLES ; i++)
		{
			int numbsOfcust= (int) (Math.random()*5 +1);


			for(int j=1; j<=numbsOfcust; j++)
			{
				tel.add(custCurrent);
				System.out.println("Customer " + custCurrent + " joined in then line" +  "There are  " + (tel.size()-1) + " customers are waiting");
				custCurrent++;
			}


			//available teller to help
			int tellerAvailable = (int) (Math.random()*4+1);

			for (int z =1; z<=4; z++)
			{


				if((tel.size()>0) && z<=tellerAvailable)
				{

					int g= tel.peek();
					System.out.println("Customer" + g + " is being serviced" );
					if(tel.isEmpty())
					{

						System.out.println("tellers are waiting");

					}

					tel.remove();
				}
			}//end of teller loop

			if(tel.isEmpty())
			{

				System.out.println("tellers are waiting");

			}






		}//end of cycles loop
		tel.clear();



	}
}