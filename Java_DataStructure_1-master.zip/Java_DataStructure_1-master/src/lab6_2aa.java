import java.util.LinkedList;
import java.util.Queue;
/*
(2)	Using Queue: Ticket Counter Simulation (2 points)
Our simulated ticket counter will use the following assumptions:
. There is only one line and it is first come, first served
. Ticket buyers arrive on average every 15 seconds
. If there is a cashier available, processing begins immediately upon arrival
. Processing a ticket buyer request takes on average two minutes (120
 seconds) from the ticket buyer reaches a cashier.
Download TicketBuyer.java from Moodle.

Use java.util.Queue to write a java program to create a queue of ticket buyers and then see how long it takes to process those ticket buyers if there is only one cashier. Then you will process the same queue of ticket buyers with two cashiers. You continue this process for up to ten cashiers. Display the average times that it takes to process a ticket buyer with different number of cashier.
 */
public class lab6_2aa
{

	public static void main ( String[] args)
	{
		int time;
		int averageT;
		int leaving;

		Queue<TicketBuyer> line = new LinkedList<TicketBuyer>();

		int[] numC = new int[10];
		TicketBuyer tix;
		int currCash =0;
		while(currCash<10){
			for (int j=1; j <= 105; j++)
				line.add((new TicketBuyer(j*15)));
			for (int i=0; i < currCash; i++)
				numC[i] = 0;
			time = 0;
			while ((line.size()!=0)){
				int k =0;
				while(k <= currCash){
					if ((line.size()!=0)){
						tix = line.remove();
						if (numC[k]< tix.getArrivalTime())
							leaving = tix.getArrivalTime() + 120;
						else
							leaving = numC[k] + 120;
						tix.setDepartureTime (leaving);
						numC[k] = leaving;
						time += tix.totalTime()-15;}
					k++;
				}

			}//end of while loop
			averageT = (time / 100);
			System.out.println ("Number of cashier # " + (currCash+1) + "\n Average time# " + averageT + "\n");


			currCash++;
		}
	}
}
