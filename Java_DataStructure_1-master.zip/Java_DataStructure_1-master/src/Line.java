//*******************************************************************
//  Line.java
//
//*******************************************************************

import java.util.LinkedList;

public class Line
{
	LinkedList queue;

	public Line()
	{
		queue = new LinkedList();
	}

	public Customer nextCustomer()
	{
		return (Customer)queue.removeFirst();
	}

	public void addCustomer(Customer person)
	{
		queue.addLast(person);
	}

	public boolean isEmpty()
	{
		return queue.isEmpty();
	}

	public int size()
	{
		return queue.size();
	}
}
