import java.util.LinkedList;
import java.util.Queue;

/*
 * (2)	Using Queue: Ticket Counter Simulation (2 points)
Our simulated ticket counter will use the following assumptions:
. There is only one line and it is first come, first served
. Ticket buyers arrive on average every 15 seconds
. If there is a cashier available, processing begins immediately upon arrival
. Processing a ticket buyer request takes on average two minutes (120
 seconds) from the ticket buyer reaches a cashier.
Download TicketBuyer.java from Moodle.

Use java.util.Queue to write a java program to create a queue of ticket buyers and then see how long it takes to process those ticket buyers if there is only one cashier. Then you will process the same queue of ticket buyers with two cashiers. You continue this process for up to ten cashiers. Display the average times that it takes to process a ticket buyer with different number of cashier.

 */
public class Lab6_2 {
	static Queue<Integer>line =new LinkedList<Integer>();
	static TicketBuyer tix;
	public static void main(String[] args){
		simplesim(2,100);
	}

	public static void simplesim(int numc, int numCash){
		Queue<TicketBuyer> linez = new LinkedList<TicketBuyer>();
		int totalTime;
		int averageTime;
		int departs;
		int time = 0;
		int cNum=0;
		line.add(cNum);
		while(line.size()!=0){
			cNum +=1;
			if(cNum!=numc){
				line.add(cNum);
			}
			line.remove();
			time+=1;
		}


		if (tix.getArrivalTime() > time)
			departs = tix.getArrivalTime() + 120;
		else
			departs = time + 120;
		tix.setDepartureTime (departs);
		time = departs;
		time += tix.totalTime();

		averageTime = time / numc;
		System.out.println ("Number of cash: " + (numCash+1));
		System.out.println ("Average time: " + averageTime + "\n");
		//System.out.printf("\n%d Cashier and %d customers will take about %d minutes to process all request with each customer waiting %d seconts.\n", numCash, numc,minutes, processTime);
	}
}







