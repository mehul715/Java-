import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
/*
 * (3)	Objective: Replacing recursive calls programming technique with using
                  Stack data structure (2 points)

Modify the StringTree.java to add method to traversal the tree using java.util.Stack instead of recursion.
At the end, display the tree to ensure the order of records is the same as the recursive method.
Download the stringFile.txt from Moodle as input for the database.

 */

public class Lab8_3 {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {

		StringTree tree = new StringTree();
		Scanner fileScan = null,
				scan = new Scanner(System.in);
		try {
			fileScan = new Scanner(new File("stringFile.txt"));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		//Reads elements from file
		while (fileScan.hasNextLine())
		{
			String s = fileScan.nextLine();
			tree.addString(s);
		}//end of while

		System.out.println("\nPrinting with Recursion ");
		System.out.println("===================");
		tree.traverseWithRecursion();
		System.out.println("\n");

		System.out.println("\nPrinting Inorder without Recursion ");
		System.out.println("===================");
		tree.inOrderWithoutRecursion();
		System.out.println("\n");

		System.out.println("\nPrinting PostOrder without Recursion ");
		System.out.println("===================");
		tree.postOrderWithoutRecursion();
		System.out.println("\n");

		System.out.println("\nPrinting PreOrder without Recursion ");
		System.out.println("===================");
		tree.preOrderWithoutRecursion();
		System.out.println("\n");



	}//end of main
}//end of class