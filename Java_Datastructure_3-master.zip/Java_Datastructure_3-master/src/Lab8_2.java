import java.io.File;
import java.util.Scanner;
/*
 * (2)	Objective: Provide range search function for Dictionary (2 point)
Add printRang method to BST.java that, given a low key value, and high key value,
 print all records in sorted order whose values fall between the two given keys.
 (Both low key and high key do not have to be keys on the list)

 */

public class Lab8_2 {
	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws Exception {
		BST bst = new BST();
		Scanner fileScan = null,
				scan = new Scanner(System.in);
		fileScan = new Scanner(new File("inventory.txt"));

		//Reads elements from file
		while (fileScan.hasNextLine())
		{
			String s = fileScan.nextLine();
			bst.insert(s, s);

		}
		System.out.println("Reading from file \n"+ bst.toString());
		System.out.println("\nRange");
		bst.printRange(bst.getRoot(), "A", "H");
	}
}
