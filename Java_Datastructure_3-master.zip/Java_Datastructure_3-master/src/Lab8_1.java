import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/*
 * (1)	Objective: Binary Search Tree traversal (2 points)

Use traversal.pptx as guidance to write a program to build a binary search tree Dictionary.
 Input records are from inventory.txt. The data for the BST <Key,E> KVpair are;
  Key is the PartNo and Element is the Inventory record from the input record.
Download traversal-lab.pptx, inventory.txt, BinNode.java, BSTNode.java, BST.java,
Dictionary.java and Inventory.java from Moodel.

Perform specifications as follow:
(a)	Provide Delete and Retrieve functions for user to access the database.
(b)	Modify BST.java to add printpostOrder, printpreOrder methods.
(c)	At the end, display inorder, postorder and preorder of the tree.

 */
public class Lab8_1 {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {

		BST bst = new BST();
		Scanner fileScan = null,
				scan = new Scanner(System.in);
		try {
			fileScan = new Scanner(new File("inventory.txt"));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		//Reads elements from file
		while (fileScan.hasNextLine())
		{
			String s = fileScan.nextLine();
			String[] lineSplit = s.split(",");
			bst.insert(lineSplit[0], s);

		}
		System.out.println("Reading from file \n==================\n"+ bst.toString());
		String another = "y", del ="x";
		Scanner input= new Scanner(System.in);
		while(another.equalsIgnoreCase("y")){
			//searching in database
			String z = null;
			while(del.equalsIgnoreCase("x")){
				try{
					System.out.println("Enter Part Number you want to search?");
					del = input.nextLine();
					System.out.println(bst.find(del));
					;
				} catch  (Exception e) {
					System.out.println("not found");
				}
				System.out.println("Enter anymore name to search?? type x for yes or type anything to quit");
				del= input.nextLine();
			}
			System.out.println("Enter key to delete from database");
			another = input.nextLine();
			bst.remove(another);

			System.out.println("\nPrinting PostOrder ");
			System.out.println("===================");
			bst.printPostOrder(bst.getRoot());

			System.out.println("\nPrinting InOrder ");
			System.out.println("===================");
			bst.printInOrder( bst.getRoot());

			System.out.println("\nPrinting PreOrder ");
			System.out.println("===================");
			bst.printPreOrder( bst.getRoot());

			System.out.println();
			System.out.println("\nWant to delete another name??, type (y/n)");
			another= input.nextLine();

		}
	}
}
